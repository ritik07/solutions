import React from "react";
import "../Css/category.css";
import IHEARTBLANK from "../Icons/iheartblank.png";
import IHEARTRED from "../Icons/iheartred.png";
const HeartRed = () => {
  return (
    <div>
      <img className="iheartblank" src={IHEARTRED} alt="" />
    </div>
  );
};

export default HeartRed;

import React from "react";
import "../Css/category.css";
import IHEARTBLANK from "../Icons/iheartblank.png";
const Heart = () => {
  return (
    <div>
      <img className="iheartblank" src={IHEARTBLANK} alt="" />
    </div>
  );
};

export default Heart;
